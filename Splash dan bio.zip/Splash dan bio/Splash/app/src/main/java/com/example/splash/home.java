package com.example.splash;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.content.Intent;


public class home extends AppCompatActivity {

    private Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        button = (Button)findViewById(R.id.button);
        button.setOnClickListener((view) -> {
            Intent i = new Intent ( home.this, biodata.class);
            startActivity(i);
        });
    }
}